============================================================================================
07/23/2008 - ABC
============================================================================================
============================================================================================

Hello, brave NChord user!

There are currently two projects included in the NChord Visual Studio solution:

	* NChordLib - this project builds the main NChord library which can be linked into 
		client or server applications.

	* NChordServer - a very basic "sample" server application that demonstrates usage
		of NChordLib to exercise basic Chord functionality.

As I'm still just getting things up and running, I've not had time to include a small test
suite, or more complete server.  These, plus a few additional (presumably more useful) 
sample applications are on their way.

It is also my hope to get extensive documentation up shortly, though old Chord pros
probably can figure most of the implementation and usage out by wandering through the code
comments.

Until then, have fun with NChord...

Andrew Cencini

============================================================================================
============================================================================================